#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RDK X5 LoRa模块通信脚本
适用于正点原子LoRa模块，自动检测可用UART端口
默认优先尝试UART2 (ttyS2)，不可用时自动回退到UART1 (ttyS1)
"""

import serial
import time
import sys
import os

# 候选串口列表（按优先级排序，运行时自动探测第一个可用的）
CANDIDATE_PORTS = [
    '/dev/ttyS2',   # UART2 (RX/TX) - 优先尝试
    '/dev/ttyS1',   # UART1
    '/dev/ttyS0',   # UART0
    '/dev/ttyAMA0', # 某些板子的串口
]


def auto_detect_port(baudrate=115200, timeout=1):
    """
    自动探测可用串口
    按 CANDIDATE_PORTS 顺序逐个尝试打开，返回第一个成功打开的端口名
    """
    print("🔍 自动探测可用串口...")
    for port in CANDIDATE_PORTS:
        if not os.path.exists(port):
            print(f"  ⏭️  {port} 设备不存在，跳过")
            continue
        try:
            ser = serial.Serial(port, baudrate, timeout=timeout)
            ser.close()
            print(f"  ✅ {port} 可用")
            return port
        except Exception as e:
            print(f"  ❌ {port}: {e}")
    print("❌ 未找到可用串口！")
    return None


class LoRaUART:
    def __init__(self, port=None, baudrate=115200, timeout=1):
        """
        初始化LoRa UART通信
        :param port: 串口设备路径，为None则自动探测
        :param baudrate: 波特率，默认为115200
        :param timeout: 超时时间(秒)
        """
        self.baudrate = baudrate
        self.timeout = timeout
        self.ser = None
        
        if port is None:
            self.port = auto_detect_port(baudrate, timeout)
            if self.port is None:
                raise RuntimeError("无法找到可用的串口设备")
        else:
            self.port = port
        
    def open_serial(self):
        """打开串口连接"""
        try:
            self.ser = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=self.timeout
            )
            
            if self.ser.is_open:
                print(f"✅ 串口 {self.port} 已成功打开")
                print(f"   波特率: {self.baudrate}")
                return True
            else:
                print(f"❌ 无法打开串口 {self.port}")
                return False
                
        except Exception as e:
            print(f"❌ 打开串口时出错: {e}")
            return False
    
    def close_serial(self):
        """关闭串口连接"""
        if self.ser and self.ser.is_open:
            self.ser.close()
            print("✅ 串口已关闭")
    
    def send_hex_data(self, hex_data):
        """
        发送十六进制数据
        :param hex_data: 十六进制字符串，如 "FF AA 01 01 EE"
        :return: 发送的字节数
        """
        if not self.ser or not self.ser.is_open:
            print("❌ 串口未打开，请先调用 open_serial()")
            return 0
        
        try:
            # 将十六进制字符串转换为字节数组
            hex_str = hex_data.replace(" ", "").replace("{", "").replace("}", "")
            data_bytes = bytes.fromhex(hex_str)
            
            # 发送数据
            sent = self.ser.write(data_bytes)
            self.ser.flush()  # 确保数据完全发送
            
            print(f"📤 已发送 {sent} 字节: {hex_data}")
            print(f"   原始字节: {data_bytes.hex().upper()}")
            
            return sent
            
        except ValueError as e:
            print(f"❌ 十六进制数据格式错误: {e}")
            return 0
        except Exception as e:
            print(f"❌ 发送数据时出错: {e}")
            return 0
    
    def send_at_command(self, at_command, expect_response=True, timeout=2):
        """
        发送AT指令
        :param at_command: AT指令字符串
        :param expect_response: 是否期待响应
        :param timeout: 响应超时时间
        :return: 响应内容
        """
        if not self.ser or not self.ser.is_open:
            print("❌ 串口未打开")
            return None
        
        # 添加换行符
        if not at_command.endswith('\r\n'):
            at_command += '\r\n'
        
        try:
            # 清空接收缓冲区
            self.ser.reset_input_buffer()
            
            # 发送AT指令
            print(f"📤 发送AT指令: {at_command.strip()}")
            self.ser.write(at_command.encode('utf-8'))
            self.ser.flush()
            
            if not expect_response:
                return None
            
            # 等待并读取响应
            time.sleep(0.1)
            response = b''
            start_time = time.time()
            
            while time.time() - start_time < timeout:
                if self.ser.in_waiting > 0:
                    response += self.ser.read(self.ser.in_waiting)
                    # 检查是否收到完整的响应
                    if b'OK' in response or b'ERROR' in response:
                        break
                time.sleep(0.01)
            
            response_str = response.decode('utf-8', errors='ignore')
            print(f"📥 收到响应: {response_str.strip()}")
            return response_str
            
        except Exception as e:
            print(f"❌ AT指令发送出错: {e}")
            return None
    
    def initialize_lora(self):
        """初始化LoRa模块"""
        print("=" * 50)
        print("🔧 初始化LoRa模块")
        print("=" * 50)
        
        # 1. 测试AT指令通信
        response = self.send_at_command("AT")
        if response and "OK" in response:
            print("✅ AT指令通信正常")
        else:
            print("⚠️  AT指令无响应，请检查连接")
            return False
        
        # 2. 获取模块信息
        self.send_at_command("AT+VER?")
        
        # 3. 设置工作模式（如果需要）
        # 常见的正点原子LoRa模块命令：
        # AT+MODE=0  # 设置工作模式（0=一般模式，1=唤醒模式，2=省电模式，3=休眠模式）
        # AT+ADDR=1  # 设置地址
        # AT+NETID=0 # 设置网络ID
        
        # 4. 设置发射功率
        # AT+POWER=20  # 设置发射功率为20dBm
        
        # 5. 设置空中速率（波特率）
        # AT+SPEED=7  # 7对应115200波特率
        
        print("✅ LoRa模块初始化完成")
        return True
    
    def receive_data(self, timeout=5):
        """
        接收数据
        :param timeout: 接收超时时间(秒)
        :return: 接收到的数据
        """
        if not self.ser or not self.ser.is_open:
            print("❌ 串口未打开")
            return None
        
        print(f"📥 等待接收数据，超时: {timeout}秒...")
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            if self.ser.in_waiting > 0:
                data = self.ser.read(self.ser.in_waiting)
                hex_str = data.hex().upper()
                ascii_str = ''.join([chr(b) if 32 <= b < 127 else '.' for b in data])
                
                print(f"📥 收到 {len(data)} 字节数据")
                print(f"   十六进制: {hex_str}")
                print(f"   ASCII: {ascii_str}")
                return data
            time.sleep(0.1)
        
        print("⏱️  接收超时，未收到数据")
        return None

def main():
    """主函数"""
    print("=" * 60)
    print("RDK X5 LoRa模块通信脚本")
    print("=" * 60)
    
    # 创建LoRa通信对象（port=None 自动探测可用串口）
    lora = LoRaUART(port=None, baudrate=115200)
    
    try:
        # 1. 打开串口
        if not lora.open_serial():
            sys.exit(1)
        
        # 2. 初始化LoRa模块（可选）
        # 如果您的LoRa模块需要初始化，取消下面一行的注释
        # lora.initialize_lora()
        
        # 3. 发送十六进制数据
        hex_data = "FF AA 01 01 EE"  # 要发送的数据
        print(f"\n🚀 准备发送数据: {{{hex_data}}}")
        
        lora.send_hex_data(hex_data)
        
        # 4. 可选：等待并接收响应
        print("\n📡 等待接收响应...")
        lora.receive_data(timeout=3)
        
        # 5. 可以连续发送多次
        print("\n🔄 发送测试完成")
        
    except KeyboardInterrupt:
        print("\n\n⚠️  用户中断")
    except Exception as e:
        print(f"\n❌ 程序运行出错: {e}")
    finally:
        # 关闭串口
        lora.close_serial()
        print("\n👋 程序结束")

if __name__ == "__main__":
    main()