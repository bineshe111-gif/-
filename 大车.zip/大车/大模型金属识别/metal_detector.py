#!/usr/bin/env python3
"""
金属异物大模型检测 ROS2 节点

功能：
  - 订阅 /send_target 话题（sensor_msgs/Image），接收待检测的图片
  - 将图片转发给 hobot_llamacpp 大模型进行金属/非金属判断
  - 将检测结果以 std_msgs/UInt8 发布到 /send_target_result（1=金属, 0=非金属）

依赖：
  - hobot_llamacpp 节点需以 feed_type:=1 模式预先启动

启动方式：
  # 终端1：启动模型服务
  source /opt/tros/humble/setup.bash
  ros2 run hobot_llamacpp hobot_llamacpp --ros-args \
    -p feed_type:=1 \
    -p model_file_name:=/home/sunrise/vit_model_int16_VL3_1B_Instruct.hbm \
    -p llm_model_name:=/home/sunrise/qwen2_5_q8_0_InternVL3_1B_Instruct.gguf

  # 终端2：启动本节点
  source /opt/tros/humble/setup.bash
  python3 /home/sunrise/model_newtest/metal_detector.py
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String, UInt8
from sensor_msgs.msg import Image
from ai_msgs.msg import PerceptionTargets
from cv_bridge import CvBridge
from collections import deque


class MetalDetector(Node):
    def __init__(self):
        super().__init__('metal_detector')

        # ---- 声明 ROS 参数 ----
        self.declare_parameter('user_prompt',
                               '你是一个材料识别专家。请逐步分析图片中物体的材料属性：\n'
                               '1. 表面特征：是否有金属光泽或反光？\n'
                               '2. 颜色纹理：颜色和纹理是否符合金属特征？\n'
                               '3. 形状结构：形状是否像金属制品？\n'
                               '4. 综合判断：基于以上分析，该物体是金属还是非金属？\n\n'
                               '请先输出分析过程，最后一行必须只输出"金属"或"非金属"。')
        self.declare_parameter('inference_timeout', 15.0)

        self.user_prompt = self.get_parameter('user_prompt').value
        self.inference_timeout = self.get_parameter('inference_timeout').value

        # ---- 工具 ----
        self.bridge = CvBridge()

        # ---- 队列与状态 ----
        self.pending_images = deque()          # 待处理图片队列
        self.busy = False                      # 是否正在等待推理结果
        self._delayed_prompt_timer = None      # 延迟发送提示词的定时器
        self.current_timeout_timer = None      # 当前图片的超时定时器

        # ---- 订阅者：接收外部发送的待检测图片（/send_target，绝对话题名以支持跨设备）----
        self.target_sub = self.create_subscription(
            Image,
            '/send_target',
            self.target_callback,
            10)

        # ---- 订阅者：接收 hobot_llamacpp 的推理结果 ----
        self.result_sub = self.create_subscription(
            PerceptionTargets,
            '/llama_cpp_node',
            self.result_callback,
            10)

        # ---- 发布者：转发给 hobot_llamacpp ----
        self.img_pub = self.create_publisher(Image, '/image', 10)
        self.prompt_pub = self.create_publisher(String, '/prompt_text', 10)

        # ---- 发布者：检测结果（1=金属, 0=非金属）----
        self.result_pub = self.create_publisher(UInt8, '/send_target_result', 10)

        self.get_logger().info(
            f'MetalDetector 已启动 '
            f'(超时={self.inference_timeout}s, 队列=FIFO)'
        )
        self.get_logger().info(
            f'订阅: /send_target → 发布: /send_target_result'
        )

    # ======================== 回调函数 ========================

    def target_callback(self, msg: Image):
        """收到 send_target 上的图片，加入队列"""
        if not self._validate_image(msg):
            self.get_logger().warn('收到无效的图片消息，已丢弃')
            return

        self.pending_images.append(msg)
        queue_len = len(self.pending_images)
        self.get_logger().info(f'图片已加入队列 (当前队列长度: {queue_len})')

        # 如果当前空闲，立即开始处理
        if not self.busy:
            self._process_next()

    def result_callback(self, msg: PerceptionTargets):
        """收到 hobot_llamacpp 的推理结果"""
        if not self.busy:
            # 不处于等待状态，忽略多余的推理结果
            return

        # 取消超时定时器
        self._cancel_timeout()

        # 解析结果
        prediction = self._parse_result(msg)
        result_code = 1 if prediction == '金属' else 0

        # 发布结果
        result_msg = UInt8()
        result_msg.data = result_code
        self.result_pub.publish(result_msg)

        self.get_logger().info(
            f'检测完成 → {"金属" if result_code else "非金属"} (UInt8: {result_code})'
        )

        # 标记空闲，处理下一张
        self.busy = False
        self._process_next()

    # ======================== 核心逻辑 ========================

    def _process_next(self):
        """从队列中取下一张图片，发送给 hobot_llamacpp 推理"""
        if not self.pending_images:
            return

        self.busy = True
        img_msg = self.pending_images.popleft()
        queue_len = len(self.pending_images)
        self.get_logger().info(
            f'处理图片 frame_id={img_msg.header.frame_id} '
            f'(剩余队列: {queue_len})'
        )

        # 步骤1：发布图片到 /image
        self.img_pub.publish(img_msg)

        # 步骤2：短暂延迟后发布提示词（确保 hobot_llamacpp 先收到图片）
        self._delayed_prompt_timer = self.create_timer(0.5, self._send_prompt)

    def _send_prompt(self):
        """发送提示词并启动超时定时器"""
        # 销毁这个一次性定时器
        if hasattr(self, '_delayed_prompt_timer') and self._delayed_prompt_timer:
            self.destroy_timer(self._delayed_prompt_timer)
            self._delayed_prompt_timer = None

        prompt_msg = String()
        prompt_msg.data = self.user_prompt
        self.prompt_pub.publish(prompt_msg)
        self.get_logger().info(f'提示词已发送: {self.user_prompt[:50]}...')

        # 启动超时定时器
        self.current_timeout_timer = self.create_timer(
            self.inference_timeout,
            self._on_timeout)

    def _on_timeout(self):
        """推理超时处理"""
        if not self.busy:
            return

        self.get_logger().warn(f'推理超时 ({self.inference_timeout}s)，发布默认结果 0')
        self._cancel_timeout()

        # 超时发布 0（非金属）
        result_msg = UInt8()
        result_msg.data = 0
        self.result_pub.publish(result_msg)

        # 标记空闲，继续处理下一张
        self.busy = False
        self._process_next()

    # ======================== 辅助方法 ========================

    def _parse_result(self, msg: PerceptionTargets) -> str:
        """
        解析 hobot_llamacpp 返回的 PerceptionTargets 消息。
        支持 Chain-of-Thought 输出：从推理过程中提取最终答案。
        返回 '金属' 或 '非金属'。
        """
        for target in msg.targets:
            result_text = target.type.replace('</s>', '').strip()
            self.get_logger().info(f'模型输出:\n{result_text}')

            # 策略：在全部文本中找最后一个"金属"或"非金属"的位置，
            # 靠后的优先（因为 CoT 最终结论通常在末尾）
            last_metal = result_text.rfind('金属')
            last_nonmetal = result_text.rfind('非金属')

            if last_metal == -1 and last_nonmetal == -1:
                self.get_logger().warn('未找到"金属"或"非金属"关键字，默认返回"非金属"')
                return '非金属'

            if last_metal > last_nonmetal:
                return '金属'
            else:
                return '非金属'

        self.get_logger().warn('推理结果 msg.targets 为空，默认返回"非金属"')
        return '非金属'

    def _validate_image(self, msg: Image) -> bool:
        """验证图片消息是否有效"""
        if msg.height == 0 or msg.width == 0:
            return False
        if len(msg.data) == 0:
            return False
        return True

    def _cancel_timeout(self):
        """取消当前的超时定时器"""
        if self.current_timeout_timer is not None:
            self.destroy_timer(self.current_timeout_timer)
            self.current_timeout_timer = None


def main():
    rclpy.init()
    node = MetalDetector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('收到中断信号，正在关闭...')
    except Exception as e:
        node.get_logger().error(f'运行异常: {e}')
    finally:
        node.destroy_node()
        # 避免重复 shutdown 时报错
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
