#!/usr/bin/env python3
"""
绞盘收线（收起）脚本 - RDK S100
使用 DRV8833 电机驱动芯片
AIN1 -> GPIO0, AIN2 -> GPIO1, STBY -> GPIO2
"""

import time
import sys
import argparse

# ------------- 配置区 -------------
# RDK S100 丝印 GPIO0/1/2 在 BCM 模式下对应 17/27/22（与 RDK X5 相同）
AIN1_PIN  = 17   # 丝印 GPIO0, Physical PIN 11, BCM 17
AIN2_PIN  = 27   # 丝印 GPIO1, Physical PIN 13, BCM 27
STBY_PIN  = 22   # 丝印 GPIO2, Physical PIN 15, BCM 22（如 STBY 接 3.3V 则设为 None）

# 默认收线时长（秒），最大时长限制
DEFAULT_DURATION = 3.0
MAX_DURATION = 60
# ----------------------------------

try:
    import Hobot.GPIO as GPIO
except ImportError:
    try:
        import RPi.GPIO as GPIO
        print("[INFO] 使用 RPi.GPIO 库")
    except ImportError:
        print("[ERROR] 未找到 GPIO 库，请安装 Hobot.GPIO 或 RPi.GPIO")
        sys.exit(1)


class WinchRetract:
    def __init__(self, ain1=AIN1_PIN, ain2=AIN2_PIN, stby=STBY_PIN):
        self.ain1 = ain1
        self.ain2 = ain2
        self.stby = stby
        self._init_gpio()

    def _init_gpio(self):
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.ain1, GPIO.OUT)
        GPIO.setup(self.ain2, GPIO.OUT)
        GPIO.output(self.ain1, GPIO.LOW)
        GPIO.output(self.ain2, GPIO.LOW)

        if self.stby is not None:
            GPIO.setup(self.stby, GPIO.OUT)
            GPIO.output(self.stby, GPIO.HIGH)  # 拉高使能芯片
            print(f"[GPIO] STBY (GPIO{self.stby}) 已使能")

    def retract(self, duration=DEFAULT_DURATION):
        """收线：AIN1=LOW, AIN2=HIGH"""
        duration = min(duration, MAX_DURATION)
        print(f">>> 收线中... ({duration:.1f} 秒)")
        GPIO.output(self.ain1, GPIO.LOW)
        GPIO.output(self.ain2, GPIO.HIGH)
        time.sleep(duration)
        self.stop()
        print(">>> 收线完成")

    def stop(self):
        """停止电机"""
        GPIO.output(self.ain1, GPIO.LOW)
        GPIO.output(self.ain2, GPIO.LOW)

    def cleanup(self):
        """释放 GPIO 资源"""
        self.stop()
        if self.stby is not None:
            GPIO.output(self.stby, GPIO.LOW)  # 休眠
        GPIO.cleanup()
        print("[GPIO] 资源已释放")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="绞盘收线控制")
    parser.add_argument("-t", "--time", type=float, default=DEFAULT_DURATION,
                        help=f"收线时长（秒），默认 {DEFAULT_DURATION}，最大 {MAX_DURATION}")
    parser.add_argument("--no-stby", action="store_true",
                        help="STBY 直接接 3.3V，不需要软件控制")
    args = parser.parse_args()

    stby_pin = None if args.no_stby else STBY_PIN
    winch = WinchRetract(stby=stby_pin)

    try:
        winch.retract(duration=args.time)
    except KeyboardInterrupt:
        print("\n[中断] 立即停止")
    finally:
        winch.cleanup()
